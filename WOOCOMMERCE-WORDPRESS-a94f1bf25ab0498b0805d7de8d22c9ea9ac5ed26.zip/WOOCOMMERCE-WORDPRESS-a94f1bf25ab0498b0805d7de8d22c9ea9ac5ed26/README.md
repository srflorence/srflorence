1. Download the repository
2. Zip the worldline_checkoutjs folder
3. Upload the worldline_checkoutjs.zip plugin